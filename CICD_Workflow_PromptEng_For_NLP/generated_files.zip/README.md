# CircleCI Error Intelligence
GOAL: Read a failed-build log, classify it, and explain it in plain
English with a concrete fix. Cut time-to-diagnosis under 5 minutes.
DATA: ci_cd_pipeline_failure_logs_dataset.csv - CI/CD failure logs
across CircleCI, GitHub Actions, GitLab CI, Jenkins, Azure DevOps.
HARD RULES:
- Never send raw logs to the model - sanitise PII first.
- Classification must use ONLY the fixed label set.
- Summaries must follow the fixed output structure.
- Judge usefulness by task metrics, not word-overlap metrics.
