from __future__ import annotations

import argparse
import csv
from collections import Counter
from dataclasses import dataclass
from math import isnan
import json
import os
import re
from pathlib import Path
from typing import Iterable, Optional, Tuple

from pii_filter import sanitise_log
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError


def _tokenize(text: str) -> list[str]:
    return [t for t in "".join(ch.lower() if ch.isalnum() else " " for ch in (text or "")).split() if t]


def rouge1_f1(reference: str, hypothesis: str) -> float:
    ref = _tokenize(reference)
    hyp = _tokenize(hypothesis)
    if not ref or not hyp:
        return 0.0

    ref_counts = Counter(ref)
    hyp_counts = Counter(hyp)
    overlap = sum((ref_counts & hyp_counts).values())
    precision = overlap / max(len(hyp), 1)
    recall = overlap / max(len(ref), 1)
    if precision + recall == 0:
        return 0.0
    return 2 * precision * recall / (precision + recall)


def _lcs_length(a: list[str], b: list[str]) -> int:
    # Classic DP, optimized to 2 rows.
    if not a or not b:
        return 0
    if len(a) < len(b):
        a, b = b, a
    prev = [0] * (len(b) + 1)
    for x in a:
        curr = [0]
        for j, y in enumerate(b, start=1):
            if x == y:
                curr.append(prev[j - 1] + 1)
            else:
                curr.append(max(prev[j], curr[j - 1]))
        prev = curr
    return prev[-1]


def rougeL_f1(reference: str, hypothesis: str) -> float:
    ref = _tokenize(reference)
    hyp = _tokenize(hypothesis)
    if not ref or not hyp:
        return 0.0

    lcs = _lcs_length(ref, hyp)
    precision = lcs / max(len(hyp), 1)
    recall = lcs / max(len(ref), 1)
    if precision + recall == 0:
        return 0.0
    return 2 * precision * recall / (precision + recall)


def bertscore_f1(reference: str, hypothesis: str) -> float:
    """
    BERTScore F1 using distilbert-base-uncased.
    Returns NaN if bert_score/transformers/torch are not available.
    """
    try:
        from bert_score import score as bert_score  # type: ignore
    except ModuleNotFoundError:
        return float("nan")

    # Note: This call will try to download model weights if not cached.
    _, _, f1 = bert_score(
        cands=[hypothesis],
        refs=[reference],
        model_type="distilbert-base-uncased",
        lang="en",
        rescale_with_baseline=False,
        verbose=False,
    )
    return float(f1[0].item())


def evaluate_summary(reference: str, hypothesis: str) -> Tuple[float, float, float]:
    """
    Returns (ROUGE-1 F1, ROUGE-L F1, BERTScore F1).
    """
    r1 = rouge1_f1(reference, hypothesis)
    rl = rougeL_f1(reference, hypothesis)
    bs = bertscore_f1(reference, hypothesis)
    return r1, rl, bs


def _load_dotenv(path: Path = Path(".env")) -> None:
    if not path.exists():
        return
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip().strip('"').strip("'")
        os.environ.setdefault(key, value)


def _post_chat_completions(prompt: str) -> str:
    _load_dotenv()
    api_key = os.environ.get("OPENAI_API_KEY", "").strip()
    api_base = os.environ.get("OPENAI_API_BASE", "https://api.openai.com/v1").rstrip("/")
    model = os.environ.get("OPENAI_MODEL", "gpt-4o-mini").strip()

    if not api_key:
        raise RuntimeError("OPENAI_API_KEY missing")

    url = f"{api_base}/chat/completions"
    headers = {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}
    payload = {
        "model": model,
        "messages": [{"role": "user", "content": prompt}],
        "temperature": 0,
        "max_tokens": 120,
    }

    req = Request(url, data=json.dumps(payload).encode("utf-8"), headers=headers, method="POST")
    with urlopen(req, timeout=60) as resp:
        data = json.loads(resp.read().decode("utf-8"))
    return data["choices"][0]["message"]["content"].strip()


def judge_summary(original_error: str, summary: str) -> tuple[int, int, str, str]:
    """
    Calls the model to score a generated summary.
    Returns (accuracy_score, actionability_score, reason, raw_response).
    """
    # Never send raw logs; sanitize defensively.
    original_safe = sanitise_log(original_error or "")
    summary_safe = sanitise_log(summary or "")

    prompt = (
        "You are evaluating an AI-generated build error explanation for a\n"
        "CircleCI developer. Original error: {original_error} Generated\n"
        "summary: {summary}. Score 1-5 on Accuracy (does it correctly describe what went wrong) "
        "and Actionability (does the fix give something concrete to do now). Respond exactly:\n"
        "ACCURACY: <score>\n"
        "ACTIONABILITY: <score>\n"
        "REASON: <one sentence>"
    ).format(original_error=original_safe, summary=summary_safe)

    raw = _post_chat_completions(prompt)

    m_acc = re.search(r"(?m)^ACCURACY:\s*([1-5])\s*$", raw)
    m_act = re.search(r"(?m)^ACTIONABILITY:\s*([1-5])\s*$", raw)
    m_reason = re.search(r"(?m)^REASON:\s*(.+)\s*$", raw)
    if not (m_acc and m_act and m_reason):
        raise ValueError("Model response did not match required format.")

    return int(m_acc.group(1)), int(m_act.group(1)), m_reason.group(1).strip(), raw


def _heuristic_judge_summary(original_error: str, summary: str) -> tuple[int, int, str]:
    """
    Offline fallback when the model is unavailable. Returns (accuracy, actionability, reason).
    """
    orig = (sanitise_log(original_error or "")).lower()
    summ = (sanitise_log(summary or "")).lower()

    # Accuracy heuristic: look for matching key signals.
    signals = [
        ("permission", "permission"),
        ("timeout", "timeout"),
        ("could not resolve host", "dns"),
        ("no matching distribution", "dependency"),
        ("npm err!", "dependency"),
        ("docker build", "docker"),
        ("keyerror", "env"),
        ("environment variable", "env"),
        ("assertionerror", "test"),
    ]
    orig_tags = {tag for needle, tag in signals if needle in orig}
    summ_tags = {tag for needle, tag in signals if needle in summ}
    overlap = len(orig_tags & summ_tags)
    accuracy = 3 if not orig_tags else max(1, min(5, 1 + overlap * 2))

    # Actionability heuristic: look for an imperative, concrete step.
    actionable_markers = ("run ", "set ", "verify ", "check ", "grant ", "retry", "open ", "add ", "update ")
    actionability = 2
    if any(m in summ for m in actionable_markers):
        actionability = 4
    if "suggested fix:" in summ and any(m in summ for m in actionable_markers):
        actionability = 5

    return accuracy, actionability, "Heuristic fallback (model unavailable in this environment)."


def _extract_what_failed(summary_text: str) -> str:
    for line in (summary_text or "").splitlines():
        if line.strip().startswith("WHAT FAILED:"):
            return line.split("WHAT FAILED:", 1)[1].strip()
    return (summary_text or "").strip().splitlines()[0].strip() if summary_text else ""


@dataclass
class SummaryRow:
    error_message: str
    original_error: str
    summary: str


def _iter_summary_rows(path: Path) -> Iterable[SummaryRow]:
    with path.open("r", encoding="utf-8", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            # Flexible column mapping.
            original_error = row.get("original_error") or row.get("error_message") or row.get("clean_error_message") or ""
            summary = row.get("summary") or row.get("pipeline_summary") or row.get("response") or row.get("model_response") or ""
            error_message = row.get("error_message") or original_error
            if (original_error or "").strip() and (summary or "").strip():
                yield SummaryRow(error_message=error_message, original_error=original_error, summary=summary)


def _find_summaries_path() -> Optional[Path]:
    candidates = [
        Path("pipeline_summaries.csv"),
        Path("pipeline_summary.csv"),
        Path("summaries.csv"),
    ]
    for p in candidates:
        if p.exists():
            return p
    return None


def _safe_preview(text: str, max_len: int = 180) -> str:
    safe = sanitise_log(text or "").replace("\r\n", "\n").replace("\r", "\n")
    safe = safe.splitlines()[0] if "\n" in safe else safe
    if len(safe) > max_len:
        safe = safe[: max_len - 3] + "..."
    return safe


def _infer_summary_from_log(clean_error_message: str) -> str:
    s = (clean_error_message or "").lower()
    if "assertionerror" in s or "expected" in s and "got" in s:
        what_failed = "Tests failed due to an assertion mismatch."
        root = "A test assertion did not match the actual output/behavior."
        fix = "Open the first failing test and compare expected vs actual to update code or the test."
    elif "permission denied" in s or "access denied" in s or "eacces" in s:
        what_failed = "A step failed due to insufficient permissions."
        root = "The job user lacked permission to read/write a required resource."
        fix = "Grant the CI job appropriate permissions or redirect outputs to a writable path."
    elif "could not resolve host" in s or "timed out" in s or "timeout" in s:
        what_failed = "A step failed due to a network timeout/DNS error."
        root = "The job could not reach a required host/service in time."
        fix = "Retry once; if persistent, validate DNS/egress and add retry/backoff around the failing call."
    elif "no matching distribution" in s or "could not find a version" in s or "npm err! 404" in s or "not found:" in s:
        what_failed = "Dependency installation failed."
        root = "A required package/version could not be resolved from the registry."
        fix = "Verify the package/version exists and registry/auth settings are correct, then re-run install."
    elif "docker build" in s or "dockerfile" in s or "failed to solve" in s:
        what_failed = "Docker image build failed."
        root = "A Dockerfile layer failed (missing files, auth, or a failing command)."
        fix = "Run `docker build` locally with the same context and fix the first failing layer."
    else:
        what_failed = "A CI step failed."
        root = "The log snippet doesn’t uniquely identify the failure category."
        fix = "Inspect the first error line in the job log and act on that specific message."

    return f"WHAT FAILED: {what_failed}\nROOT CAUSE: {root}\nSUGGESTED FIX: {fix}"


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--path", type=str, default="", help="CSV with original_error + summary columns")
    ap.add_argument("--limit", type=int, default=10, help="Max rows to print")
    ap.add_argument("--judge", action="store_true", help="Judge summaries with the model (fallback if unavailable)")
    args = ap.parse_args()

    summaries_path = Path(args.path) if args.path else _find_summaries_path()
    rows: list[SummaryRow] = []

    if summaries_path is not None and summaries_path.exists():
        for r in _iter_summary_rows(summaries_path):
            rows.append(r)
            if len(rows) >= args.limit:
                break
    else:
        # Best-effort fallback so the script can be demonstrated without a summaries file.
        cleaned_path = Path("cleaned_logs.csv")
        if not cleaned_path.exists():
            raise FileNotFoundError(
                "No pipeline summaries CSV found, and cleaned_logs.csv is missing. "
                "Provide a summaries file via --path."
            )
        print("NOTE: No pipeline summaries CSV found; using cleaned_logs.csv + heuristic summaries for demo.\n")
        with cleaned_path.open("r", encoding="utf-8", newline="") as f:
            reader = csv.DictReader(f)
            for row in reader:
                original = row.get("clean_error_message") or ""
                if not original.strip():
                    continue
                summary = _infer_summary_from_log(original)
                error_msg = row.get("error_message") or original
                rows.append(SummaryRow(error_message=error_msg, original_error=original, summary=summary))
                if len(rows) >= args.limit:
                    break

    if not rows:
        if summaries_path is None:
            print("No usable rows found (need original_error + summary).")
        else:
            print(f"No usable rows found in {summaries_path} (need original_error + summary).")
        return

    # NOTE: ROUGE is a lexical overlap metric. A low ROUGE score here does not imply a bad
    # summary because good troubleshooting summaries often paraphrase, compress, and add
    # actionable steps that are not present verbatim in the log text.

    print("error_message | rouge1_f1 | rougeL_f1 | bertscore_f1")
    for r in rows:
        hypothesis = _extract_what_failed(r.summary)
        rouge1, rougeL, bs = evaluate_summary(reference=r.original_error, hypothesis=hypothesis)
        bs_str = "NA" if isnan(bs) else f"{bs:.3f}"
        print(f"{_safe_preview(r.error_message)} | {rouge1:.3f} | {rougeL:.3f} | {bs_str}")

    if not args.judge:
        return

    print("\nJudgements (ACCURACY/ACTIONABILITY):")
    for r in rows:
        try:
            acc, act, reason, _raw = judge_summary(r.original_error, r.summary)
        except (HTTPError, URLError, RuntimeError, ValueError):
            acc, act, reason = _heuristic_judge_summary(r.original_error, r.summary)
        print(f"{_safe_preview(r.error_message)} | {acc} | {act} | {reason}")


if __name__ == "__main__":
    main()
