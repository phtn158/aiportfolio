from __future__ import annotations

import csv
import json
import os
import re
import sys
from pathlib import Path
from typing import Iterable
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError

from pii_filter import sanitise_log


LABELS = (
    "dependency_resolution_failure",
    "test_assertion_failure",
    "misconfigured_script",
    "environment_variable_missing",
    "network_timeout",
    "permission_denied",
    "docker_build_failure",
    "unknown",
)


def _load_dotenv(path: Path = Path(".env")) -> None:
    """
    Minimal .env loader (avoids external deps). Does not print values.
    """
    if not path.exists():
        return

    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip().strip('"').strip("'")
        os.environ.setdefault(key, value)


def _post_json(url: str, headers: dict[str, str], payload: dict) -> dict:
    data = json.dumps(payload).encode("utf-8")
    req = Request(url, data=data, headers=headers, method="POST")
    with urlopen(req, timeout=60) as resp:
        return json.loads(resp.read().decode("utf-8"))


def classify_error(error_message: str) -> str:
    """
    Classify a (sanitised) CI/CD error log into exactly one fixed label.
    Returns ONLY the label as a plain string.
    """
    _load_dotenv()
    api_key = os.environ.get("OPENAI_API_KEY", "").strip()
    api_base = os.environ.get("OPENAI_API_BASE", "https://api.openai.com/v1").rstrip("/")
    model = os.environ.get("OPENAI_MODEL", "gpt-4o-mini").strip()

    def heuristic_classify(msg: str) -> str:
        s = (msg or "").lower()

        # Not represented in our fixed label set; prefer unknown.
        if any(k in s for k in ("oomkilled", "out of memory", "killed", "error 137", "container exceeded its memory")):
            return "unknown"

        if any(k in s for k in ("permission denied", "eacces", "access denied", "operation not permitted", "unauthorized", "forbidden")):
            return "permission_denied"

        if any(k in s for k in ("timed out", "timeout", "etimedout", "econnreset", "temporary failure in name resolution", "could not resolve host", "connection reset")):
            return "network_timeout"

        if any(k in s for k in ("env var", "environment variable", "not set", "is not set", "missing env", "undefined variable", "keyerror:", "no value for required")):
            return "environment_variable_missing"

        if any(k in s for k in ("docker build", "dockerfile", "failed to solve", "error building image", "buildkit", "pull access denied", "failed to build")):
            return "docker_build_failure"

        if any(k in s for k in ("assertionerror", "expected:", "to equal", "assert ", "pytest", "jest", "tests failed", "failed:")):
            return "test_assertion_failure"

        if any(k in s for k in ("npm err! 404", "not found:", "no matching distribution", "could not find a version", "pip install", "requirements.txt", "yarn add", "pnpm add", "dependency", "dependencies")):
            return "dependency_resolution_failure"

        if any(
            k in s
            for k in (
                "command not found",
                "no such file or directory",
                "unknown option",
                "invalid option",
                "syntax error",
                "configuration error",
                "misconfigured",
                "invalid yaml",
                "cannot find",
                "mypy",
                "type error",
                "undefined:",
                "imported and not used",
                "exit status 2",
            )
        ):
            return "misconfigured_script"

        return "unknown"

    if not api_key:
        return heuristic_classify(sanitise_log(error_message or ""))

    # Hard rule: never send raw logs; re-sanitise defensively.
    safe_text = sanitise_log(error_message or "")

    system = (
        "You are a strict classifier for CI/CD failure logs.\n"
        "Choose exactly one label from:\n"
        + "\n".join(f"- {l}" for l in LABELS)
        + "\nReturn ONLY the label, nothing else."
    )
    user = f"Log:\n{safe_text}"

    url = f"{api_base}/chat/completions"
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
    }
    payload = {
        "model": model,
        "messages": [
            {"role": "system", "content": system},
            {"role": "user", "content": user},
        ],
        "temperature": 0,
        "max_tokens": 16,
    }

    try:
        resp = _post_json(url, headers=headers, payload=payload)
        content = resp["choices"][0]["message"]["content"].strip()
    except (KeyError, IndexError, ValueError, HTTPError, URLError):
        return heuristic_classify(safe_text)

    # Normalize and validate.
    label = content.strip().strip('"').strip("'")
    label = re.sub(r"\s+", "", label)
    if label in LABELS:
        return label
    return heuristic_classify(safe_text)


def classify_error_fewshot(error_message: str) -> str:
    """
    Few-shot variant of classify_error(). Includes 3 labelled examples before the question.
    Returns ONLY the label as a plain string.
    """
    _load_dotenv()
    api_key = os.environ.get("OPENAI_API_KEY", "").strip()
    api_base = os.environ.get("OPENAI_API_BASE", "https://api.openai.com/v1").rstrip("/")
    model = os.environ.get("OPENAI_MODEL", "gpt-4o-mini").strip()

    safe_text = sanitise_log(error_message or "")

    # If we can't reach the model, fall back deterministically.
    if not api_key:
        return classify_error(safe_text)

    system = (
        "You are a strict classifier for CI/CD failure logs.\n"
        "Choose exactly one label from:\n"
        + "\n".join(f"- {l}" for l in LABELS)
        + "\nReturn ONLY the label, nothing else."
    )

    fewshot = (
        "Error: \"npm ERR! 404 Not Found: lodash@4.17.21\"\n"
        "Category: dependency_resolution_failure\n\n"
        "Error: \"AssertionError: expected 200 but got 404 at test_api_response\"\n"
        "Category: test_assertion_failure\n\n"
        "Error: \"Permission denied: cannot write to /var/log/app.log\"\n"
        "Category: permission_denied\n\n"
        "Now classify:\n"
        f"Error: \"{safe_text}\""
    )

    url = f"{api_base}/chat/completions"
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
    }
    payload = {
        "model": model,
        "messages": [
            {"role": "system", "content": system},
            {"role": "user", "content": fewshot},
        ],
        "temperature": 0,
        "max_tokens": 16,
    }

    try:
        resp = _post_json(url, headers=headers, payload=payload)
        content = resp["choices"][0]["message"]["content"].strip()
    except (KeyError, IndexError, ValueError, HTTPError, URLError):
        return classify_error(safe_text)

    label = content.strip().strip('"').strip("'")
    label = re.sub(r"\s+", "", label)
    if label in LABELS:
        return label
    return classify_error(safe_text)


def classify_error_cot(error_message: str) -> tuple[str, str]:
    """
    Ambiguity helper that asks the model for *surface* clues + a brief justification,
    then returns the parsed label from the final line `CATEGORY: <label>`.

    NOTE: We intentionally do NOT request or print hidden chain-of-thought. The model
    is instructed to provide only observable clues and a short decision rationale.
    """
    _load_dotenv()
    api_key = os.environ.get("OPENAI_API_KEY", "").strip()
    api_base = os.environ.get("OPENAI_API_BASE", "https://api.openai.com/v1").rstrip("/")
    model = os.environ.get("OPENAI_MODEL", "gpt-4o-mini").strip()

    safe_text = sanitise_log(error_message or "")

    if not api_key:
        label = classify_error(safe_text)
        return label, "(model unavailable)\\nCATEGORY: " + label

    system = (
        "You are a strict classifier for CI/CD failure logs.\n"
        "Choose exactly one label from:\n"
        + "\n".join(f"- {l}" for l in LABELS)
        + "\nDo NOT reveal private chain-of-thought. Provide only:\n"
        "- CLUES: bullet list of exact phrases/symptoms seen in the log\n"
        "- DECISION: 1-2 sentences why the best label fits\n"
        "The last line MUST be exactly: CATEGORY: <label>"
    )
    user = f"Log (sanitised):\n{safe_text}"

    url = f"{api_base}/chat/completions"
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
    }
    payload = {
        "model": model,
        "messages": [
            {"role": "system", "content": system},
            {"role": "user", "content": user},
        ],
        "temperature": 0,
        "max_tokens": 200,
    }

    try:
        resp = _post_json(url, headers=headers, payload=payload)
        content = resp["choices"][0]["message"]["content"].strip()
    except (KeyError, IndexError, ValueError, HTTPError, URLError) as e:
        label = classify_error(safe_text)
        return label, f"(model call failed: {e})\nCATEGORY: {label}"

    lines = [ln.strip() for ln in content.splitlines() if ln.strip()]
    last = lines[-1] if lines else ""
    m = re.match(r"^CATEGORY:\s*([a-z_]+)\s*$", last)
    if m:
        label = m.group(1)
        if label in LABELS:
            return label, content

    fallback = classify_error(safe_text)
    return fallback, content + f"\nCATEGORY: {fallback}"


# Back-compat for the user typo in the request.
lassify_error_cot = classify_error_cot


def classify_with_consistency(error_message: str, n: int = 5) -> tuple[str, float, list[str]]:
    """
    Runs classify_error_cot() n times and returns:
    - majority label
    - confidence score (majority_count / n)
    - the list of labels from each run

    High disagreement across runs (e.g., 2/5, 2/5, 1/5) usually means the message is
    ambiguous, underspecified, or contains mixed signals; treat it as low-confidence
    and consider requesting more context or defaulting to `unknown`.
    """
    if n <= 0:
        raise ValueError("n must be >= 1")

    safe_text = sanitise_log(error_message or "")
    labels: list[str] = []
    for _ in range(n):
        label, _ = classify_error_cot(safe_text)
        labels.append(label)

    counts: dict[str, int] = {}
    for label in labels:
        counts[label] = counts.get(label, 0) + 1

    # Majority vote; break ties deterministically by preferring `unknown`, then alpha.
    max_count = max(counts.values())
    winners = sorted([k for k, v in counts.items() if v == max_count])
    majority = "unknown" if "unknown" in winners else winners[0]
    confidence = max_count / n
    return majority, confidence, labels


def _iter_rows(path: Path) -> Iterable[dict[str, str]]:
    with path.open("r", encoding="utf-8", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            yield row


def _preview(text: str, max_len: int = 240) -> str:
    safe = sanitise_log(text or "").replace("\r\n", "\n").replace("\r", "\n")
    if len(safe) > max_len:
        safe = safe[: max_len - 3] + "..."
    return safe


def main() -> None:
    dataset_path = Path("cleaned_logs.csv")
    if not dataset_path.exists():
        raise FileNotFoundError("cleaned_logs.csv not found. Run pii_filter.py first.")

    rows: list[dict[str, str]] = []
    for row in _iter_rows(dataset_path):
        if (row.get("clean_error_message") or "").strip():
            rows.append(row)
        if len(rows) >= 10:
            break

    if not rows:
        print("No rows with clean_error_message found.")
        return

    results: list[tuple[str, str, str, str]] = []
    for row in rows:
        text_for_display = row.get("error_message") or row.get("clean_error_message") or ""
        text_for_model = row.get("clean_error_message") or ""
        zero = classify_error(text_for_model)
        few = classify_error_fewshot(text_for_model)
        actual = row.get("failure_type", "")
        results.append((_preview(text_for_display), zero, few, actual))

    # Comparison table
    print("error_message | zero_shot_label | few_shot_label | actual_failure_type")
    for msg, zero, few, actual in results:
        print(f"{msg} | {zero} | {few} | {actual}")

    # Disagreements
    disagreements = [(m, z, f, a) for (m, z, f, a) in results if z != f]
    print("\nDisagreements:")
    if not disagreements:
        print("(none)")
    else:
        for idx, (msg, zero, few, actual) in enumerate(disagreements, start=1):
            print(f"\n=== Disagreement {idx} ===")
            print(f"error_message (sanitised preview):\n{msg}")
            print(f"zero_shot_label: {zero}")
            print(f"few_shot_label: {few}")
            print(f"actual_failure_type: {actual}")

            cot_label, cot_text = classify_error_cot(msg)
            print("\nCOT-style output (clues + brief decision; last line parsed):")
            print(cot_text)
            resolved = (cot_label == zero) != (cot_label == few)
            print(f"\nParsed CATEGORY label: {cot_label}")
            print(f"Does it resolve the disagreement (picks one side)? {resolved}")

    # Consistency demo on 3 intentionally ambiguous (sanitised) messages.
    ambiguous_messages = [
        "npm ERR! network timeout while trying to fetch lodash@4.17.21 (ETIMEDOUT)",
        "docker build failed: permission denied while accessing /var/lib/docker",
        "tests failed during setup: KeyError: 'API_TOKEN' (env var not set) while installing dependencies",
    ]

    print("\nConsistency test (n=5) on 3 ambiguous messages:")
    for i, msg in enumerate(ambiguous_messages, start=1):
        majority, conf, runs = classify_with_consistency(msg, n=5)
        print(f"\nAmbiguous message {i}: {msg}")
        for j, label in enumerate(runs, start=1):
            print(f"  Run {j}: {label}")
        print(f"  Voted label: {majority} (confidence {conf:.2f})")


if __name__ == "__main__":
    main()
