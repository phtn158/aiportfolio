from __future__ import annotations

import csv
from pathlib import Path
from typing import Any, Iterable

from pii_filter import sanitise_log
from classifier import classify_with_consistency
import summariser
import evaluator

try:
    import pandas as pd  # type: ignore
except ModuleNotFoundError:  # pragma: no cover
    pd = None  # type: ignore


def _iter_rows(df: Any, n_rows: int) -> Iterable[dict[str, Any]]:
    """
    Supports either:
    - pandas.DataFrame
    - list[dict]
    - any iterable of dict-like rows
    """
    if pd is not None and hasattr(df, "iloc") and hasattr(df, "columns"):
        limit = min(int(n_rows), int(len(df)))
        for i in range(limit):
            # to_dict() ensures plain python types.
            yield df.iloc[i].to_dict()  # type: ignore[no-any-return]
        return

    if isinstance(df, list):
        for row in df[:n_rows]:
            yield dict(row)
        return

    count = 0
    for row in df:
        yield dict(row)
        count += 1
        if count >= n_rows:
            break


def _extract_what_failed(summary_text: str) -> str:
    for line in (summary_text or "").splitlines():
        if line.strip().startswith("WHAT FAILED:"):
            return line.split("WHAT FAILED:", 1)[1].strip()
    return ""


def _safe_preview(text: str, max_len: int = 160) -> str:
    safe = sanitise_log(text or "").replace("\r\n", "\n").replace("\r", "\n")
    safe = safe.splitlines()[0] if "\n" in safe else safe
    if len(safe) > max_len:
        safe = safe[: max_len - 3] + "..."
    return safe


def full_pipeline(df: Any, n_rows: int = 10):
    """
    End-to-end pipeline:
    - takes n_rows
    - sanitises error_message
    - classifies with classify_with_consistency
    - generates a summary with persona + output spec prompt
    - evaluates with evaluate_summary (ROUGE/BERTScore) and judge_summary (Accuracy/Actionability)
    - returns a results "dataframe" (pandas if available; else list[dict])
    - saves results.csv
    """
    results: list[dict[str, Any]] = []

    for idx, row in enumerate(_iter_rows(df, n_rows), start=1):
        ci_tool = str(row.get("ci_tool", "") or "")
        failure_stage = str(row.get("failure_stage", "") or "")
        severity = str(row.get("severity", "") or "")

        raw_error = str(row.get("error_message", "") or row.get("clean_error_message", "") or "")
        safe_error = sanitise_log(raw_error)

        majority_label, confidence, runs = classify_with_consistency(safe_error, n=5)

        filled_prompt = summariser.error_summary_prompt.format(
            ci_tool=ci_tool,
            failure_stage=failure_stage,
            severity=severity,
            error_message=safe_error,
        )
        try:
            summary = summariser._post_chat_completions(filled_prompt)  # type: ignore[attr-defined]
        except Exception:
            summary = summariser._local_fallback_summary_new(  # type: ignore[attr-defined]
                ci_tool, failure_stage, severity, safe_error
            )

        what_failed = _extract_what_failed(summary)
        rouge1, rougeL, bertscore = evaluator.evaluate_summary(reference=safe_error, hypothesis=what_failed)

        try:
            acc, act, reason, raw_judge = evaluator.judge_summary(safe_error, summary)
        except Exception:
            acc, act, reason = evaluator._heuristic_judge_summary(safe_error, summary)  # type: ignore[attr-defined]
            raw_judge = ""

        results.append(
            {
                "row_index": idx,
                "ci_tool": ci_tool,
                "failure_stage": failure_stage,
                "severity": severity,
                "sanitised_error_message": safe_error,
                "sanitised_error_preview": _safe_preview(safe_error),
                "consistency_runs": "|".join(runs),
                "consistency_majority_label": majority_label,
                "consistency_confidence": confidence,
                "filled_prompt": filled_prompt,
                "summary": summary,
                "what_failed": what_failed,
                "rouge1_f1": rouge1,
                "rougeL_f1": rougeL,
                "bertscore_f1": bertscore,
                "judge_accuracy": acc,
                "judge_actionability": act,
                "judge_reason": reason,
                "judge_raw_response": raw_judge,
            }
        )

    out_path = Path("results.csv")
    if pd is not None:
        out_df = pd.DataFrame(results)
        out_df.to_csv(out_path, index=False)
        return out_df

    # Dependency-free CSV write
    fieldnames: list[str] = []
    seen = set()
    for r in results:
        for k in r.keys():
            if k not in seen:
                seen.add(k)
                fieldnames.append(k)

    with out_path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for r in results:
            writer.writerow(r)

    return results


def _load_cleaned_logs(n_rows: int) -> list[dict[str, Any]]:
    path = Path("cleaned_logs.csv")
    if not path.exists():
        raise FileNotFoundError("cleaned_logs.csv not found. Run pii_filter.py first.")
    rows: list[dict[str, Any]] = []
    with path.open("r", encoding="utf-8", newline="") as f:
        reader = csv.DictReader(f)
        for r in reader:
            rows.append(r)
            if len(rows) >= n_rows:
                break
    return rows


def main() -> None:
    rows = _load_cleaned_logs(10)
    _ = full_pipeline(rows, n_rows=10)
    out_path = Path("results.csv")
    print(f"Created: {out_path} (exists={out_path.exists()})")


if __name__ == "__main__":
    main()

