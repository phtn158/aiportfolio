from __future__ import annotations

import csv
from pathlib import Path

import evaluator
import summariser


def _load_lowest_rows(n: int = 3) -> list[dict[str, str]]:
    path = Path("results.csv")
    if not path.exists():
        raise FileNotFoundError("results.csv not found. Run pipeline.py first.")

    rows: list[dict[str, str]] = []
    with path.open("r", encoding="utf-8", newline="") as f:
        reader = csv.DictReader(f)
        for r in reader:
            rows.append(r)

    rows.sort(key=lambda r: int(float(r.get("judge_actionability") or 0)))
    return rows[:n]


def _summarise_with_updated_prompt(row: dict[str, str]) -> str:
    ci_tool = row.get("ci_tool", "")
    failure_stage = row.get("failure_stage", "")
    severity = row.get("severity", "")
    error_message = row.get("sanitised_error_message", "") or row.get("original_error", "") or ""

    filled = summariser.error_summary_prompt.format(
        ci_tool=ci_tool,
        failure_stage=failure_stage,
        severity=severity,
        error_message=error_message,
    )
    try:
        return summariser._post_chat_completions(filled)  # type: ignore[attr-defined]
    except Exception:
        return summariser._local_fallback_summary_new(  # type: ignore[attr-defined]
            ci_tool, failure_stage, severity, error_message
        )


def main() -> None:
    rows = _load_lowest_rows(3)

    for i, row in enumerate(rows, start=1):
        original_error = row.get("sanitised_error_message", "") or row.get("original_error", "") or ""
        old_summary = row.get("summary", "") or ""
        old_reason = row.get("judge_reason", "") or ""
        old_acc = row.get("judge_accuracy", "")
        old_act = row.get("judge_actionability", "")

        print(f"\n=== Low-actionability row {i} ===")
        print("original_error:")
        print(original_error)
        print("\nold_summary:")
        print(old_summary)
        print(f"\nold_judge: ACCURACY={old_acc} ACTIONABILITY={old_act}")
        print(f"old_reason: {old_reason}")

        new_summary = _summarise_with_updated_prompt(row)
        try:
            new_acc, new_act, new_reason, _raw = evaluator.judge_summary(original_error, new_summary)
        except Exception:
            new_acc, new_act, new_reason = evaluator._heuristic_judge_summary(original_error, new_summary)  # type: ignore[attr-defined]

        print("\nnew_summary:")
        print(new_summary)
        print(f"\nnew_judge: ACCURACY={new_acc} ACTIONABILITY={new_act}")
        print(f"new_reason: {new_reason}")

        improved = (float(new_act) > float(old_act or 0)) if str(old_act).strip() else False
        print(f"\nDid actionability improve vs old score? {improved}")


if __name__ == "__main__":
    main()
