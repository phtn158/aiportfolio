from __future__ import annotations

import csv
import json
import os
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen


try:
    # Real LangChain (preferred)
    from langchain_core.prompts import PromptTemplate  # type: ignore
except ModuleNotFoundError:  # pragma: no cover

    class PromptTemplate:  # minimal shim with the same .format() contract
        def __init__(self, *, input_variables: list[str], template: str):
            self.input_variables = input_variables
            self.template = template

        def format(self, **kwargs: str) -> str:
            return self.template.format(**kwargs)


def _load_dotenv(path: Path = Path(".env")) -> None:
    if not path.exists():
        return
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip().strip('"').strip("'")
        os.environ.setdefault(key, value)


def _post_chat_completions(prompt: str) -> str:
    """
    Sends the filled prompt to an OpenAI-compatible /chat/completions endpoint.
    Returns assistant text, or raises on failure.
    """
    _load_dotenv()
    api_key = os.environ.get("OPENAI_API_KEY", "").strip()
    api_base = os.environ.get("OPENAI_API_BASE", "https://api.openai.com/v1").rstrip("/")
    model = os.environ.get("OPENAI_MODEL", "gpt-4o-mini").strip()

    if not api_key:
        raise RuntimeError("OPENAI_API_KEY missing")

    url = f"{api_base}/chat/completions"
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
    }
    payload = {
        "model": model,
        "messages": [
            {
                "role": "system",
                "content": "Explain CI/CD failures clearly and safely. Do not ask for secrets.",
            },
            {"role": "user", "content": prompt},
        ],
        "temperature": 0.2,
        "max_tokens": 350,
    }

    req = Request(url, data=json.dumps(payload).encode("utf-8"), headers=headers, method="POST")
    with urlopen(req, timeout=60) as resp:
        data = json.loads(resp.read().decode("utf-8"))
    return data["choices"][0]["message"]["content"].strip()


def _local_fallback_summary_old(error_message: str) -> str:
    msg = (error_message or "").strip()
    if not msg:
        return "1) What happened: Build failed.\n2) Likely root cause: Unknown.\n3) Concrete fix: Check the failing step logs.\n4) Quick verification: Re-run the job."
    first_line = msg.splitlines()[0].strip()
    return (
        f"1) What happened: The pipeline failed while running: {first_line}\n"
        "2) Likely root cause: The build step encountered an error reported in the log.\n"
        "3) Concrete fix (steps): Identify the first error line and fix the referenced config/code/package.\n"
        "4) Quick verification (1 command): Re-run the failed CI step locally or re-run the job."
    )


def _local_fallback_summary_new(ci_tool: str, failure_stage: str, severity: str, error_message: str) -> str:
    s = (error_message or "").lower()

    if "permission denied" in s or "access denied" in s or "eacces" in s:
        fix = "Grant the job/user write access to the target path or change output to a writable directory."
        root = "The job attempted an operation without sufficient filesystem permissions."
        failed = "A step failed due to a permission error."
    elif "keyerror" in s or "is not set" in s or "environment variable" in s or "undefined variable" in s:
        fix = "Set the missing environment variable in the CI project settings (and verify it’s available in this job context)."
        root = "A required environment variable was missing at runtime."
        failed = "A step failed because a required environment variable was missing."
    elif "could not resolve host" in s or "timed out" in s or "timeout" in s:
        fix = "Run `nslookup <host>` (or `dig <host>`) in the job environment to confirm DNS, then fix DNS/egress allowlists and re-run."
        root = "The job couldn’t reach an external/internal host within the allowed time."
        failed = "A step failed due to a network timeout/DNS issue."
    elif "no space left on device" in s or "disk usage" in s or "enospc" in s:
        fix = "Clear CI caches/workspace artifacts (or increase executor disk) and re-run the job."
        root = "The runner ran out of disk space while writing build/test artifacts."
        failed = "A step failed because the runner ran out of disk space."
    elif "npm err!" in s or "no matching distribution" in s or "could not find a version" in s or "not found:" in s:
        fix = "Verify the dependency/version exists and the registry URL/auth is correct, then re-run the install step."
        root = "The dependency manager couldn’t resolve or fetch a required package version."
        failed = "Dependency installation failed."
    elif "gitleaks" in s or "secret" in s and "leak" in s:
        fix = "Rotate the exposed credential immediately, remove it from the repo history, and add it to CI secrets management."
        root = "A secret scanner detected a leaked credential in the codebase/log output."
        failed = "A security scan failed due to a detected secret leak."
    elif "docker build" in s or "dockerfile" in s or "failed to solve" in s:
        fix = "Run `docker build` locally with the same context/Dockerfile and fix the first failing layer (often missing files or auth)."
        root = "The Docker image build failed during a Dockerfile step."
        failed = "Docker image build failed."
    else:
        fix = "Open the failing step and act on the first error line (it usually points to the real cause), then re-run the job."
        root = "The log indicates a build/test/tooling error, but the exact category isn’t clear from this snippet."
        failed = "A CI step failed."

    # Force exact 3-line structure.
    return (
        f"WHAT FAILED: {failed}\n"
        f"ROOT CAUSE: {root}\n"
        f"SUGGESTED FIX: {fix}"
    )


def _print_side_by_side(left: str, right: str, width: int = 78) -> None:
    left_lines = (left or "").splitlines() or [""]
    right_lines = (right or "").splitlines() or [""]
    n = max(len(left_lines), len(right_lines))
    left_lines += [""] * (n - len(left_lines))
    right_lines += [""] * (n - len(right_lines))

    print("OLD OUTPUT".ljust(width) + " | " + "NEW OUTPUT")
    print(("-" * width) + "-+-" + ("-" * width))
    for l, r in zip(left_lines, right_lines, strict=True):
        print(l[:width].ljust(width) + " | " + r[:width])


# Old prompt kept for side-by-side comparison.
old_error_summary_prompt = PromptTemplate(
    input_variables=["ci_tool", "failure_stage", "error_message", "severity"],
    template=(
        "You are helping a developer diagnose a CI/CD failure.\n"
        "Explain in plain English for a developer who did not write the failing code.\n"
        "Be concrete and actionable.\n\n"
        "CI tool: {ci_tool}\n"
        "Failure stage: {failure_stage}\n"
        "Severity: {severity}\n"
        "Sanitised error log:\n"
        "{error_message}\n\n"
        "Respond with:\n"
        "1) What happened (1-2 sentences)\n"
        "2) Likely root cause\n"
        "3) Concrete fix (steps)\n"
        "4) Quick verification (1 command)\n"
    ),
)

# Improved prompt (requested): persona + exact output spec.
error_summary_prompt = PromptTemplate(
    input_variables=["ci_tool", "failure_stage", "error_message", "severity"],
    template=(
        "You are a senior DevOps engineer with 10 years of experience debugging CI/CD pipelines on CircleCI, GitHub Actions, and Jenkins.\n"
        "Explain the failure in plain English for a developer who did not write the failing code.\n"
        "Be specific and pick ONE actionable next step that can be done immediately.\n\n"
        "CI tool: {ci_tool}\n"
        "Failure stage: {failure_stage}\n"
        "Severity: {severity}\n"
        "Sanitised error log:\n"
        "{error_message}\n\n"
        "Actionability rule for SUGGESTED FIX: it must be a single concrete action (a command to run, or a single CI config change).\n"
        "Avoid vague advice like 'check the logs'. Examples:\n"
        "- If you see 'Could not resolve host' => suggest running `nslookup <host>` or `dig <host>` in the job and checking DNS/egress allowlists.\n"
        "- If you see 'No space left on device' => suggest clearing workspace/caches or increasing disk and re-running.\n\n"
        "Output MUST be exactly 3 lines, in this exact format:\n"
        "WHAT FAILED: <one sentence>\n"
        "ROOT CAUSE: <one sentence>\n"
        "SUGGESTED FIX: <one actionable step the developer can take right now>\n"
    ),
)


def main() -> None:
    in_path = Path("cleaned_logs.csv")
    if not in_path.exists():
        raise FileNotFoundError("cleaned_logs.csv not found. Run pii_filter.py first.")

    rows: list[dict[str, str]] = []
    with in_path.open("r", encoding="utf-8", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            if (row.get("clean_error_message") or "").strip():
                rows.append(row)
            if len(rows) >= 3:
                break

    if not rows:
        print("No rows with clean_error_message found.")
        return

    if "langchain_core" not in str(type(error_summary_prompt)):
        print("NOTE: LangChain is not installed; using a minimal PromptTemplate shim.\n")

    for i, row in enumerate(rows, start=1):
        filled_old = old_error_summary_prompt.format(
            ci_tool=row.get("ci_tool", ""),
            failure_stage=row.get("failure_stage", ""),
            severity=row.get("severity", ""),
            error_message=row.get("clean_error_message", ""),
        )

        filled_new = error_summary_prompt.format(
            ci_tool=row.get("ci_tool", ""),
            failure_stage=row.get("failure_stage", ""),
            severity=row.get("severity", ""),
            error_message=row.get("clean_error_message", ""),
        )

        print(f"\n=== Row {i}: FILLED PROMPT (old; exactly sent) ===")
        print(filled_old)
        print(f"=== Row {i}: FILLED PROMPT (new; exactly sent) ===")
        print(filled_new)

        old_out: str
        new_out: str

        try:
            old_out = _post_chat_completions(filled_old)
        except (HTTPError, URLError, RuntimeError, KeyError, ValueError) as e:
            old_out = f"(model call failed: {e})\n{_local_fallback_summary_old(row.get('clean_error_message', ''))}"

        try:
            new_out = _post_chat_completions(filled_new)
        except (HTTPError, URLError, RuntimeError, KeyError, ValueError) as e:
            new_out = f"(model call failed: {e})\n{_local_fallback_summary_new(row.get('ci_tool',''), row.get('failure_stage',''), row.get('severity',''), row.get('clean_error_message',''))}"

        print(f"=== Row {i}: OLD vs NEW OUTPUT (side-by-side) ===")
        _print_side_by_side(old_out, new_out)


if __name__ == "__main__":
    main()
