from __future__ import annotations

import csv
from dataclasses import dataclass
from pathlib import Path
from statistics import mean
from typing import Callable

import evaluator
import summariser


@dataclass
class LogRow:
    ci_tool: str
    failure_stage: str
    severity: str
    original_error: str


def _load_rows(n: int = 5) -> list[LogRow]:
    path = Path("cleaned_logs.csv")
    if not path.exists():
        raise FileNotFoundError("cleaned_logs.csv not found. Run pii_filter.py first.")

    rows: list[LogRow] = []
    with path.open("r", encoding="utf-8", newline="") as f:
        reader = csv.DictReader(f)
        for r in reader:
            msg = (r.get("clean_error_message") or "").strip()
            if not msg:
                continue
            rows.append(
                LogRow(
                    ci_tool=r.get("ci_tool", ""),
                    failure_stage=r.get("failure_stage", ""),
                    severity=r.get("severity", ""),
                    original_error=msg,
                )
            )
            if len(rows) >= n:
                break
    return rows


def _gen_basic(row: LogRow) -> str:
    filled = summariser.old_error_summary_prompt.format(
        ci_tool=row.ci_tool,
        failure_stage=row.failure_stage,
        severity=row.severity,
        error_message=row.original_error,
    )
    try:
        return summariser._post_chat_completions(filled)  # type: ignore[attr-defined]
    except Exception:
        return summariser._local_fallback_summary_old(row.original_error)  # type: ignore[attr-defined]


def _gen_persona_spec(row: LogRow) -> str:
    filled = summariser.error_summary_prompt.format(
        ci_tool=row.ci_tool,
        failure_stage=row.failure_stage,
        severity=row.severity,
        error_message=row.original_error,
    )
    try:
        return summariser._post_chat_completions(filled)  # type: ignore[attr-defined]
    except Exception:
        return summariser._local_fallback_summary_new(  # type: ignore[attr-defined]
            row.ci_tool, row.failure_stage, row.severity, row.original_error
        )


def _gen_cot(row: LogRow) -> str:
    # "Chain-of-thought" technique: we request surface clues + brief reasoning,
    # then a final 3-line output spec. We store only the final 3 lines.
    prompt = (
        "List the CLUES (exact phrases) that indicate the failure type, then briefly explain why.\n"
        "Finally output exactly 3 lines in this exact format:\n"
        "WHAT FAILED: <one sentence>\n"
        "ROOT CAUSE: <one sentence>\n"
        "SUGGESTED FIX: <one actionable step the developer can take right now>\n\n"
        f"CI tool: {row.ci_tool}\n"
        f"Failure stage: {row.failure_stage}\n"
        f"Severity: {row.severity}\n"
        f"Sanitised error log:\n{row.original_error}\n"
    )
    try:
        raw = summariser._post_chat_completions(prompt)  # type: ignore[attr-defined]
        lines = [ln.strip() for ln in raw.splitlines() if ln.strip()]
        # take the last 3 lines that start with required prefixes (robust to extra text)
        wanted = []
        for ln in lines:
            if ln.startswith("WHAT FAILED:") or ln.startswith("ROOT CAUSE:") or ln.startswith("SUGGESTED FIX:"):
                wanted.append(ln)
        if len(wanted) >= 3:
            return "\n".join(wanted[-3:])
        return raw
    except Exception:
        # Fallback: same structure as persona+spec.
        return summariser._local_fallback_summary_new(  # type: ignore[attr-defined]
            row.ci_tool, row.failure_stage, row.severity, row.original_error
        )


def _judge(original_error: str, summary: str) -> tuple[int, int, str]:
    try:
        acc, act, reason, _raw = evaluator.judge_summary(original_error, summary)
        return acc, act, reason
    except Exception:
        acc, act, reason = evaluator._heuristic_judge_summary(original_error, summary)  # type: ignore[attr-defined]
        return acc, act, reason


def main() -> None:
    rows = _load_rows(5)

    techniques: list[tuple[str, Callable[[LogRow], str]]] = [
        ("basic_template", _gen_basic),
        ("persona_output_spec", _gen_persona_spec),
        ("chain_of_thought", _gen_cot),
    ]

    actionability_avgs: dict[str, float] = {}

    for name, gen in techniques:
        scores = []
        print(f"\n=== Technique: {name} ===")
        for i, row in enumerate(rows, start=1):
            summary = gen(row)
            acc, act, reason = _judge(row.original_error, summary)
            scores.append(act)
            print(f"\nRow {i}")
            print(summary)
            print(f"ACCURACY: {acc}")
            print(f"ACTIONABILITY: {act}")
            print(f"REASON: {reason}")
        actionability_avgs[name] = mean(scores) if scores else 0.0

    best = max(actionability_avgs.items(), key=lambda kv: kv[1])
    print("\n=== Result ===")
    for k, v in actionability_avgs.items():
        print(f"{k}: avg_actionability={v:.2f}")
    print(f"\nHighest average actionability: {best[0]} ({best[1]:.2f})")


if __name__ == "__main__":
    main()

