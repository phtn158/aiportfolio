from __future__ import annotations

from pathlib import Path
import re
from collections import Counter
import csv

try:
    import pandas as pd  # type: ignore
except ModuleNotFoundError:  # pragma: no cover
    pd = None  # type: ignore


def _redact_for_display(value: object) -> object:
    if not isinstance(value, str) or not value:
        return value

    text = value

    # Emails
    text = re.sub(r"\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b", "<REDACTED_EMAIL>", text, flags=re.IGNORECASE)
    # IPv4
    text = re.sub(r"\b(?:\d{1,3}\.){3}\d{1,3}\b", "<REDACTED_IP>", text)
    # URLs
    text = re.sub(r"\bhttps?://\S+\b", "<REDACTED_URL>", text, flags=re.IGNORECASE)
    # Common secret/token-ish strings (conservative)
    text = re.sub(r"\bgh[pousr]_[A-Za-z0-9]{20,}\b", "<REDACTED_GH_TOKEN>", text)  # GitHub tokens
    text = re.sub(r"\bAKIA[0-9A-Z]{16}\b", "<REDACTED_AWS_KEY_ID>", text)  # AWS access key id
    text = re.sub(r"\b[A-Za-z0-9+/=]{32,}\b", "<REDACTED_SECRET>", text)  # long base64-ish blobs
    text = re.sub(r"\b[0-9a-f]{32,}\b", "<REDACTED_HEX>", text, flags=re.IGNORECASE)  # long hex strings

    if len(text) > 240:
        text = text[:237] + "..."

    return text


def _find_dataset_path() -> Path:
    candidates = [
        Path("ci_cd_pipeline_failure_logs_dataset.csv"),
        Path("ci_cd_pipeline_failure_logs.csv"),
    ]
    for path in candidates:
        if path.exists():
            return path
    raise FileNotFoundError(f"Could not find dataset. Looked for: {', '.join(str(p) for p in candidates)}")


def main() -> None:
    dataset_path = _find_dataset_path()

    print(f"Dataset: {dataset_path}")

    desired_cols = [
        "ci_tool",
        "failure_type",
        "failure_stage",
        "error_message",
        "severity",
        "pipeline_success",
    ]

    if pd is not None:
        df = pd.read_csv(dataset_path)

        print(f"Shape: {df.shape}")
        print("\nColumns + dtypes:")
        for col, dtype in df.dtypes.items():
            print(f"- {col}: {dtype}")

        present_cols = [c for c in desired_cols if c in df.columns]
        missing_cols = [c for c in desired_cols if c not in df.columns]

        print("\n5-row sample (PII redacted for display only):")
        sample = df[present_cols].head(5).copy()
        for col in sample.columns:
            if sample[col].dtype == "object":
                sample[col] = sample[col].map(_redact_for_display)
        print(sample.to_string(index=False))
        if missing_cols:
            print(f"\nMissing expected columns: {missing_cols}")

        if "failure_type" in df.columns:
            print("\nFailure type counts:")
            print(df["failure_type"].value_counts(dropna=False).to_string())
        else:
            print("\nFailure type counts: (column missing)")

        if "failure_stage" in df.columns:
            print("\nFailure stage counts:")
            print(df["failure_stage"].value_counts(dropna=False).to_string())
        else:
            print("\nFailure stage counts: (column missing)")

        if "ci_tool" in df.columns:
            circleci_rows = (
                df["ci_tool"]
                .astype(str)
                .str.strip()
                .str.lower()
                .eq("circleci")
                .sum()
            )
            print(f"\nCircleCI rows: {circleci_rows}")
        else:
            print("\nCircleCI rows: (ci_tool column missing)")
        return

    # Fallback (no pandas installed): still prints the requested exploration output.
    print("NOTE: pandas is not installed in this environment; using csv fallback.\n")

    with dataset_path.open("r", encoding="utf-8", newline="") as f:
        reader = csv.DictReader(f)
        fieldnames = reader.fieldnames or []

        row_count = 0
        sample_rows: list[dict[str, str]] = []
        failure_type_counts: Counter[str] = Counter()
        failure_stage_counts: Counter[str] = Counter()
        circleci_rows = 0

        for row in reader:
            row_count += 1

            if len(sample_rows) < 5:
                sample_rows.append(row)

            ft = row.get("failure_type")
            if ft is not None:
                failure_type_counts[ft] += 1

            fs = row.get("failure_stage")
            if fs is not None:
                failure_stage_counts[fs] += 1

            tool = (row.get("ci_tool") or "").strip().lower()
            if tool == "circleci":
                circleci_rows += 1

    print(f"Shape: ({row_count}, {len(fieldnames)})")
    print("\nColumns + dtypes:")
    for col in fieldnames:
        print(f"- {col}: string (csv fallback)")

    print("\n5-row sample (PII redacted for display only):")
    present_cols = [c for c in desired_cols if c in fieldnames]
    missing_cols = [c for c in desired_cols if c not in fieldnames]

    if present_cols:
        print(" | ".join(present_cols))
        for row in sample_rows:
            parts = []
            for col in present_cols:
                parts.append(str(_redact_for_display(row.get(col, ""))))
            print(" | ".join(parts))
    else:
        print("(none of the requested sample columns were present)")
    if missing_cols:
        print(f"\nMissing expected columns: {missing_cols}")

    print("\nFailure type counts:")
    if "failure_type" in fieldnames:
        for k, v in failure_type_counts.most_common():
            print(f"{k}: {v}")
    else:
        print("(column missing)")

    print("\nFailure stage counts:")
    if "failure_stage" in fieldnames:
        for k, v in failure_stage_counts.most_common():
            print(f"{k}: {v}")
    else:
        print("(column missing)")

    print(f"\nCircleCI rows: {circleci_rows}")


if __name__ == "__main__":
    main()
