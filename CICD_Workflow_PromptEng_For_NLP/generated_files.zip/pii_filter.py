from __future__ import annotations

from pathlib import Path
import csv
import re


def sanitise_log(text: str) -> str:
    """
    Sanitise raw build logs before sending to an LLM.

    Rules:
    - Remove long alphanumeric strings of 20+ chars (token-like).
    - Replace absolute file paths with [FILEPATH].
    - Replace env assignments KEY=VALUE with KEY=[REDACTED].
    """
    if not text:
        return text

    cleaned = text

    # 1) Token-like: long alphanumeric blobs (20+)
    cleaned = re.sub(r"\b[A-Za-z0-9]{20,}\b", "[REDACTED_TOKEN]", cleaned)

    # 2) Absolute file paths (Windows + POSIX)
    # Windows drive paths: C:\... or C:/...
    cleaned = re.sub(r"\b[A-Za-z]:(?:\\|/)[^\s\"'<>|]+", "[FILEPATH]", cleaned)
    # UNC paths: \\server\share\...
    cleaned = re.sub(r"\\\\[^\s\\]+\\[^\s\"'<>|]+", "[FILEPATH]", cleaned)
    # POSIX absolute paths: /var/... /home/... etc
    cleaned = re.sub(r"(?<!\w)/(?:[^\s\"'<>|]+/)*[^\s\"'<>|]+", "[FILEPATH]", cleaned)

    # 3) Environment assignments: KEY=VALUE -> KEY=[REDACTED]
    # Restrict KEY shape to reduce false positives.
    # Handles: KEY=value, KEY="value", KEY='value'
    cleaned = re.sub(
        r"(?m)\b([A-Z][A-Z0-9_]{1,})\s*=\s*(\"[^\"]*\"|'[^']*'|[^\s]+)",
        r"\1=[REDACTED]",
        cleaned,
    )

    return cleaned


def _display_safe_preview(text: str, max_len: int = 240) -> str:
    """
    Never print raw logs. This is an extra-safe preview for console output.
    """
    if not text:
        return text

    preview = text
    # Apply the same sanitizer plus extra conservative redactions for display.
    preview = sanitise_log(preview)
    preview = re.sub(r"\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b", "[REDACTED_EMAIL]", preview, flags=re.I)
    preview = re.sub(r"\bhttps?://\S+\b", "[REDACTED_URL]", preview, flags=re.I)
    preview = re.sub(r"\b(?:\d{1,3}\.){3}\d{1,3}\b", "[REDACTED_IP]", preview)

    preview = preview.replace("\r\n", "\n").replace("\r", "\n")
    if len(preview) > max_len:
        preview = preview[: max_len - 3] + "..."
    return preview


def _find_dataset_path() -> Path:
    candidates = [
        Path("ci_cd_pipeline_failure_logs_dataset.csv"),
        Path("ci_cd_pipeline_failure_logs.csv"),
    ]
    for path in candidates:
        if path.exists():
            return path
    raise FileNotFoundError(f"Could not find dataset. Looked for: {', '.join(str(p) for p in candidates)}")


def main() -> None:
    dataset_path = _find_dataset_path()
    out_path = Path("cleaned_logs.csv")

    printed = 0

    with dataset_path.open("r", encoding="utf-8", newline="") as f_in, out_path.open(
        "w", encoding="utf-8", newline=""
    ) as f_out:
        reader = csv.DictReader(f_in)
        if reader.fieldnames is None:
            raise ValueError("CSV appears to have no header row (fieldnames).")

        fieldnames = list(reader.fieldnames)
        if "clean_error_message" not in fieldnames:
            fieldnames.append("clean_error_message")

        writer = csv.DictWriter(f_out, fieldnames=fieldnames)
        writer.writeheader()

        for row in reader:
            original = row.get("error_message", "") or ""
            cleaned = sanitise_log(original)
            row["clean_error_message"] = cleaned
            writer.writerow(row)

            if printed < 3 and original.strip():
                printed += 1
                print(f"\nExample {printed}")
                print("Before (safe preview):")
                print(_display_safe_preview(original))
                print("After:")
                print(_display_safe_preview(cleaned))

    print(f"\nSaved: {out_path}")


if __name__ == "__main__":
    main()

